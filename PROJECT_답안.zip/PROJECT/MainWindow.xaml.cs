﻿using System.ComponentModel;
using System.IO.IsolatedStorage;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace PROJECT
{
    public partial class MainWindow : Window
    {
        private DrawInfo draw_info = new DrawInfo { DrawBrush = SystemColors.WindowFrameBrush, Thick = 10 };
        public MainWindow()
        {
            InitializeComponent();

            dockpanel.DataContext = draw_info;
        }

        //========================
        private Point cp = new Point();

        private void canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && radioLine.IsChecked.Value)
            {
                cp = e.GetPosition(canvas);
            }
            else if ( radioRect.IsChecked.Value ) 
            {
                cp = e.GetPosition(canvas);

                Rectangle r = new Rectangle();

                Canvas.SetLeft(r, cp.X);
                Canvas.SetTop(r, cp.Y);

                r.Width = 100;
                r.Height = 100;
                r.Fill = draw_info.DrawBrush;

                canvas.Children.Add(r);
            }
            else if (radioCircle.IsChecked.Value)
            {
                cp = e.GetPosition(canvas);

                Ellipse c = new Ellipse();

                Canvas.SetLeft(c, cp.X);
                Canvas.SetTop(c, cp.Y);

                c.Width = 100;
                c.Height = 100;
                c.Fill = draw_info.DrawBrush;

                canvas.Children.Add(c);
            }
        }

        private void canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && radioLine.IsChecked.Value )
            {
                Point pt = e.GetPosition(canvas);

                Line line = new Line();

                line.Stroke = draw_info.DrawBrush;
                line.StrokeThickness = draw_info.Thick;

                line.X1 = cp.X;
                line.Y1 = cp.Y;
                line.X2 = pt.X;
                line.Y2 = pt.Y;

                canvas.Children.Add(line);

                cp = pt;
                                
                label.Content = canvas.Children.Count;
            }
        }
        //---------------------------------------
        // 메뉴 핸들러
        public void Submit(object sender, ExecutedRoutedEventArgs e) 
        {
            MessageBox.Show("수고하셨습니다");
        }

        public void Close(object sender, ExecutedRoutedEventArgs e) 
        {
            Application.Current.Shutdown();
        }
        public void New(object sender, ExecutedRoutedEventArgs e) 
        {
            canvas.Children.Clear();
            label.Content = canvas.Children.Count;
        }

        public void CanNew(object sender, CanExecuteRoutedEventArgs e) 
        {
            if (canvas != null )
            {
                e.CanExecute = canvas.Children.Count != 0;
            }
        }

    }
}