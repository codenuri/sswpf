﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace PROJECT
{
    class DrawInfo : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        private int thick;
        private byte red = 0;
        private byte green = 0;
        private byte blue = 0;


        private Brush draw_brush = new SolidColorBrush(Colors.Black);

        public int Thick
        {
            get { return thick; }
            set
            {
                thick = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Thick"));
            }
        }
        public Brush DrawBrush
        {
            get { return draw_brush; }
            set
            {
                draw_brush = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("DrawBrush"));
            }
        }


        public byte Red
        {
            get { return red; }
            set
            {
                red = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Red"));

                DrawBrush = new SolidColorBrush(Color.FromRgb(red, green, blue));
            }
        }
        public byte Green
        {
            get { return green; }
            set
            {
                green = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Green"));

                DrawBrush = new SolidColorBrush(Color.FromRgb(red, green, blue));
            }
        }
        public byte Blue
        {
            get { return blue; }
            set
            {
                blue = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Blue"));

                DrawBrush = new SolidColorBrush(Color.FromRgb(red, green, blue));
            }
        }
    }
}
